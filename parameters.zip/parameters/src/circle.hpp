//
//  circle.hpp
//  parameters
//
//  Created by Amina on 3/27/21.
//

#ifndef circle_hpp
#define circle_hpp

#include <ofMain.h>

class Circle {
public:
    void setup();
    ofParameterGroup params;
    ofParameter<ofVec3f> colors;
    ofParameter<int> x;
    ofParameter<int> y;
    
};

#endif /* circle_hpp */
